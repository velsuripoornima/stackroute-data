import { Track } from './track';

describe('Track', () => {
  it('should create an instance', () => {
    expect(new Track()).toBeTruthy();
  });
});
