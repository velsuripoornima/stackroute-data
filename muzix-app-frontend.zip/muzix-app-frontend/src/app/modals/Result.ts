
import { TrackMatches } from './TrackMatches';

export interface Result {
    results : TrackMatches
}