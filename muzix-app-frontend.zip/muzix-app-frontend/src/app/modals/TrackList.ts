import {Track} from './Track';

export interface TrackList {
    track : Track[]
}   