import { TrackList } from './TrackList';

export interface TrackMatches {
    trackmatches : TrackList
}