# Spring-Boot-Muzix-assignment



Muzix Application Case Study
1 Name of Project Muzix Application
2 Objective/Vision This is an online application that helps users manage music
listed on Music Database (https://www.last.fm).
Using this app, a user should be able to search and
manage music.
3 Users of the system All Internet users
4 Functional
Requirements 1. Application should allow all the users to perform the
following activities:
a. Save track information such as trackId,
trackName, comments of the track.
b. Display saved track.
c. Update comments of saved track.
d. Remove track
5 Non-Functional
Requirements
1. App should be accessible from any location with access
to the Internet.
2. App should be responsive to display consistently across
multiple device screens.
3. App should have an intuitive UI that can be operated by
novice expert Internet users.
6 Tools and technologies
to be used
