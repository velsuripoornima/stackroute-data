package com.stackroute.MusixAppAssignment.model;

import java.util.List;

public class Trackmatches {

    private List<Track> track;

    public void setTrack(List<Track> track){
        this.track = track;
    }
    public List<Track> getTrack(){
        return this.track;
    }

}
