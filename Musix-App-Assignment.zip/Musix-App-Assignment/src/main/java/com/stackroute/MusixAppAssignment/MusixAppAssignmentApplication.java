package com.stackroute.MusixAppAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusixAppAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusixAppAssignmentApplication.class, args);
	}

}
