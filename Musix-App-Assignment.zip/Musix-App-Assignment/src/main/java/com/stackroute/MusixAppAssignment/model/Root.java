package com.stackroute.MusixAppAssignment.model;

public class Root {

    private Results results;

    public void setResults(Results results){
        this.results = results;
    }
    public Results getResults(){
        return this.results;
    }
}
