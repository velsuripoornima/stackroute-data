package com.stackroute.MusixAppAssignment.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;
@Document
@Builder
@Setter
@Getter
@AllArgsConstructor
public class TrackDto {
    private static int counter = 0;

    private int id;

    private String name;

    private String artist;

    @Id
    private String url;
    private String streamable;
    private int listeners;

    public TrackDto() {
        id = ++counter;
    }
}
