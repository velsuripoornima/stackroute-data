package com.stackroute.MusixAppAssignment.service;

import com.stackroute.MusixAppAssignment.exceptions.TrackNotFoundException;
import com.stackroute.MusixAppAssignment.exceptions.UserAlreadyExistException;
import com.stackroute.MusixAppAssignment.model.Track;
import com.stackroute.MusixAppAssignment.model.TrackDto;


import java.util.List;

public interface TrackService {

    //creating methods

    public TrackDto saveTrack(TrackDto track) throws UserAlreadyExistException;

    public List<TrackDto> getAllTrack();

    public TrackDto updateTrack(TrackDto track, int id) throws TrackNotFoundException;

    public Track deleteTrack(int id);


}
